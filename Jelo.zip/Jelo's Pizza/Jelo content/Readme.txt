Logo designed using Online Logo Maker
https://onlinelogomaker.com

Fonts used in this project:



Instructions to install fonts on windows: 
 1- Find and Download your fonts from the links above 
 2- Double click the .ttf file 
 3- Click on the install button and allow it to install